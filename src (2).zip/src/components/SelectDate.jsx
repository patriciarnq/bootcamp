// import React, { Component } from 'react';

// class SelectDate extends Component { 

//     render() { 
//             let Selecting = this.props.Selecting;
//             console.log(this.props.Selecting);
      
      
      
//             getRooms.map((Selecting, index) =>{
//             return (

// <select name="date">
//     <option value={guestRoon.roomTypes}>March 1, 2019</option>
//     <option value="saab">March 2, 2019</option>
//     <option value="fiat">March 3, 2019</option>
//     <option value="audi">March 4, 2019</option>
//     <option value="audi">March 5, 2019</option>
//   </select>
            
//         );
    
//             }
//         }
//     }

//   export {
//     SelectDate

//   }