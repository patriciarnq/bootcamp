import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';

class GuestTable extends Component { 

    render() {
        let getGuest = this.props.getGuest;
        console.log(this.props.getGuest);
    
        return (
            <Fragment>
                <table className='guestInfo-table'>
                <thead>

                </thead>
                <tbody>
                    <tr className='guestInfo-table-row'>
                        <th className='guestInfo-table-cell'>Guest ID</th>
                        <th className='guestInfo-table-cell'>First Name</th>
                        <th className='guestInfo-table-cell'>Last Name</th>
                        <th className='guestInfo-table-cell'>Age</th>
                        <th className='guestInfo-table-cell'>Email</th>
                        <th className='guestInfo-table-cell'>Address</th>
                        <th className='guestInfo-table-cell'></th>
                    </tr>
                    {
                            getGuest.map((guestInformation, index) =>{
                            return (
                                <tr className='guestInfo-table-row'>
                                    <th className='guestInfo-table-cell'>{guestInformation.id}</th>
                                    <th className='guestInfo-table-cell'>{guestInformation.firstName}</th>
                                    <th className='guestInfo-table-cell'>{guestInformation.lastName}</th>
                                    <th className='guestInfo-table-cell'>{guestInformation.lage}</th>
                                    <th className='guestInfo-table-cell'>{guestInformation.emailAdd}</th>
                                    <th className='guestInfo-table-cell'>{guestInformation.address}</th>
                                    <th className='guestInfo-table-cell'><button type='button' onClick={() => this.props.editUser(index)}>Edit</button></th>
                                </tr>
                            )
                    })
                    }
                </tbody>
                </table>
            </Fragment>
        );
    }
}

export {
    GuestTable
}