import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';

class RoomsTable extends Component { 

    render() {
        let getRooms = this.props.getRooms;
        console.log(this.props.getRooms);
        
        return (
            <Fragment>
                <table className='guestRooms-table'>
                <thead>

                </thead>
                
                
                <tbody>
                    <tr className='guestRooms-table-row'>
                        <th className='guests-table-cell'>Room Type</th>
                        <th className='guests-table-cell'>Price</th>
                        <th className='guests-table-cell'>Details</th>
                        <th className='guests-table-cell'>Status</th>
                        <th className='guests-table-cell'></th>
                    </tr>
                    {
                            getRooms.map((guestRooms, index) =>{
                            return (
                                <tr className='guestRooms-table-row'>

                                    <th className='guestRooms-table-cell'>{guestRooms.roomTypes}</th>
                                    <th className='guestRooms-table-cell'>{guestRooms.price}</th>
                                    <th className='guestRooms-table-cell'>{guestRooms.details}</th>
                                    <th className='guestRooms-table-cell'>{guestRooms.status}</th>
                                    <th className='guestRooms-table-cell'><button class='button'  onClick={(e) => (index)}>Book</button></th>
                                </tr>
                            )
                    })
                    }
                </tbody>
                </table>
            </Fragment>
        );
    }
}

export {
    RoomsTable
}