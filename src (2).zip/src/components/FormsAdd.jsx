import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';

class FormsAdd extends Component { 

    render() {
    
        return (
            <Fragment>
                <form>
                    First Name: <br/> <input type="text" name="firstName" placeholder="First Name" onChange={this.props.handleChangeInfo} /><br/>
                    Last Name: <br/> <input type="text" name="lastName" placeholder="Last Name" onChange={this.props.handleChangeInfo} /><br/>
                    Age: <br/> <input type="text" name="age" placeholder="Age" onChange={this.props.handleChangeInfo} /><br/>
                    Email Add: <br/> <input type="text" name="emailAdd" placeholder="Email Address" onChange={this.props.handleChangeInfo} /><br/>
                    Address: <br/> <input type="text" name="address" placeholder="Address" onChange={this.props.handleChangeInfo} /><br/>
                  
                    <br/>
                    <button class="buttonAdd" onClick={this.props.handleAddUser}>Proceed to Payment</button>
                </form>
            </Fragment>
        );
    }
}

FormsAdd.propTypes = {
    handleChangeInfo: PropTypes.func,
    handleAddUser: PropTypes.func
}

export {
    FormsAdd
}
