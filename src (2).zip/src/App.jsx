import React, { Component } from 'react';
import './App.css';
import axios from 'axios';

import './css/rooms-css.css';
import './css/formsAdd-css.css';
import { RoomsTable } from './components/RoomsTable';
//import { SelectDate } from './components/SelectDate';
import { FormsAdd } from './components/FormsAdd';


class App extends Component {
  
  constructor(props) {
    super(props);

    this.state = {
   //   getGuest: []
      getRooms: [],
      user: [],
      Selecting: [],
      book:[]

    }
  }

handleChangeInfo = e => {
  const {name, value} = e.target;

  this.setState((prevState) => ({
    user: {
      ...prevState.user,
      [name]: value
    }
  }));
}

handleAddUser = e => {

  let user = this.state.user;
  console.log(user)
  axios.post('http://localhost:8080/Hotel_Billing_System/v1/GuestInformation/addGuest', user, {headers: {
      "content-type": "application/json", 
      
    }}).then(res=>{console.log(res);});
    e.preventDefault();

}
// componentDidMount() {

//   axios.get('http://localhost:8080/Hotel_Billing_System/v1/GuestInformation/addGuest')
//     .then(res => {this.setState({getGuest: res.data})
//     });
//   }

    componentDidMount() {
      axios.get('http://localhost:8080/Hotel_Billing_System/v1/RoomTypes/getRoom')
        .then(res => {this.setState({getRooms: res.data});
        console.log("hello");
        console.log(res.data)
        });
      }

    render() {

      return (
        <div className="App">
        
        {/* <div className='Dropdown'>
          <h2>Select Date</h2>
            <SelectDate />
          </div>
         */}

        <div className='table-panes'>
          <h1>Room Types</h1>
            <RoomsTable getRooms={this.state.getRooms} />
          </div>

          <div className='forms-panel'>
          <h1>Guest Information</h1>
          <h2>Fill up the Form</h2>
            <FormsAdd 
              handleChangeInfo={this.handleChangeInfo} 
              handleAddUser={this.handleAddUser} />
          </div>
        </div>         

      );
    }

  }
export default App;
